extends CharacterBody2D

# -------------------------------------------------
# PLAYER STATS
# -------------------------------------------------

@export var max_health : int = 100
@export var move_speed : float = 250.0
@export var damage : int = 20

var current_health : int


# -------------------------------------------------
# REFERENCES
# -------------------------------------------------

@onready var camera = $Camera2D
@onready var animation = $AnimationPlayer


# -------------------------------------------------
# READY
# -------------------------------------------------

func _ready():

	current_health = max_health


# -------------------------------------------------
# MOVEMENT
# -------------------------------------------------

func _physics_process(delta):

	move_player()

	look_at(get_global_mouse_position())


func move_player():

	var direction = Vector2.ZERO

	if Input.is_action_pressed("move_right"):
		direction.x += 1

	if Input.is_action_pressed("move_left"):
		direction.x -= 1

	if Input.is_action_pressed("move_down"):
		direction.y += 1

	if Input.is_action_pressed("move_up"):
		direction.y -= 1

	direction = direction.normalized()

	velocity = direction * move_speed

	move_and_slide()


# -------------------------------------------------
# DAMAGE
# -------------------------------------------------

func take_damage(amount : int):

	current_health -= amount

	current_health = max(current_health,0)

	if current_health <= 0:

		die()


# -------------------------------------------------
# HEAL
# -------------------------------------------------

func heal(amount : int):

	current_health += amount

	current_health = min(current_health,max_health)


# -------------------------------------------------
# UPGRADES
# -------------------------------------------------

func increase_health(amount : int):

	max_health += amount

	current_health += amount


func increase_damage(amount : int):

	damage += amount


func increase_speed(amount : float):

	move_speed += amount


# -------------------------------------------------
# GETTERS
# -------------------------------------------------

func get_health():

	return current_health


func get_max_health():

	return max_health


func get_damage():

	return damage


func get_speed():

	return move_speed


# -------------------------------------------------
# DEATH
# -------------------------------------------------

func die():

	print("PLAYER DIED")

	queue_free()
